export const rm = (n) => 'RM ' + (Math.round((Number(n) || 0) * 100) / 100).toFixed(2);

export const esc = (s) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

// Placeholder image for sample products (no external files needed).
export const placeholderImg = (emoji = '🍽️', hue = 210) =>
  'data:image/svg+xml;utf8,' +
  encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" width="480" height="360"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="hsl(${hue},70%,86%)"/><stop offset="1" stop-color="hsl(${hue},60%,70%)"/></linearGradient></defs><rect width="480" height="360" fill="url(#g)"/><text x="240" y="225" font-size="130" text-anchor="middle">${emoji}</text></svg>`
  );

export const imgOf = (p) => p.image || placeholderImg(p.emoji, p.hue);
export const asset = (name) => import.meta.env.BASE_URL + name;
export const ORDER_TYPES = { pickup: 'Ambil Sendiri', delivery: 'Penghantaran', dinein: 'Makan di Kedai' };
export const PAYMENTS = { cash: 'Tunai', duitnow: 'DuitNow QR (sahkan manual)', bank: 'Pindahan Bank (sahkan manual)', cod: 'Bayar Semasa Terima (COD)' };
